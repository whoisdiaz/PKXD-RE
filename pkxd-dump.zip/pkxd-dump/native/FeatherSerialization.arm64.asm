; Static ARM64 disassembly of the supplied libil2cpp.so.
; ELF executable PT_LOAD virtual address and file offset both start at zero.
; Method bounds from consecutive definitions in dump.cs. Branch labels from script.json.
; No source reconstruction, execution, or wire-protocol validation implied.

; FeatherSerialization.Serialize: RVA 0x359FB04 .. 0x359FFA4 (exclusive)
0359FB04  f6 0f 1d f8  str      x22, [sp, #-0x30]!
0359FB08  f5 53 01 a9  stp      x21, x20, [sp, #0x10]
0359FB0C  f3 7b 02 a9  stp      x19, x30, [sp, #0x20]
0359FB10  94 10 01 d0  adrp     x20, #0x57b1000
0359FB14  f3 f2 00 90  adrp     x19, #0x53fb000
0359FB18  88 0a 47 39  ldrb     w8, [x20, #0x1c2]
0359FB1C  73 0a 44 f9  ldr      x19, [x19, #0x810]
0359FB20  f5 03 01 aa  mov      x21, x1
0359FB24  88 04 00 37  tbnz     w8, #0, #0x359fbb4
0359FB28  a0 ee 00 90  adrp     x0, #0x5373000
0359FB2C  00 d0 41 f9  ldr      x0, [x0, #0x3a0]
0359FB30  c1 6f 70 97  bl       #0x11bba34
0359FB34  a0 f1 00 f0  adrp     x0, #0x53d6000
0359FB38  00 08 44 f9  ldr      x0, [x0, #0x810]
0359FB3C  be 6f 70 97  bl       #0x11bba34
0359FB40  e0 ef 00 d0  adrp     x0, #0x539d000
0359FB44  00 30 40 f9  ldr      x0, [x0, #0x60]
0359FB48  bb 6f 70 97  bl       #0x11bba34
0359FB4C  20 ef 00 f0  adrp     x0, #0x5386000
0359FB50  00 08 41 f9  ldr      x0, [x0, #0x210]
0359FB54  b8 6f 70 97  bl       #0x11bba34
0359FB58  c0 f0 00 b0  adrp     x0, #0x53b8000
0359FB5C  00 d4 41 f9  ldr      x0, [x0, #0x3a8]
0359FB60  b5 6f 70 97  bl       #0x11bba34
0359FB64  00 f3 00 90  adrp     x0, #0x53ff000
0359FB68  00 18 46 f9  ldr      x0, [x0, #0xc30]
0359FB6C  b2 6f 70 97  bl       #0x11bba34
0359FB70  e0 f2 00 90  adrp     x0, #0x53fb000
0359FB74  00 08 44 f9  ldr      x0, [x0, #0x810]
0359FB78  af 6f 70 97  bl       #0x11bba34
0359FB7C  00 ee 00 90  adrp     x0, #0x535f000
0359FB80  00 bc 45 f9  ldr      x0, [x0, #0xb78]
0359FB84  ac 6f 70 97  bl       #0x11bba34
0359FB88  c0 f1 00 f0  adrp     x0, #0x53da000
0359FB8C  00 a8 40 f9  ldr      x0, [x0, #0x150]
0359FB90  a9 6f 70 97  bl       #0x11bba34
0359FB94  c0 f1 00 b0  adrp     x0, #0x53d8000
0359FB98  00 5c 40 f9  ldr      x0, [x0, #0xb8]
0359FB9C  a6 6f 70 97  bl       #0x11bba34
0359FBA0  c0 f0 00 f0  adrp     x0, #0x53ba000
0359FBA4  00 44 43 f9  ldr      x0, [x0, #0x688]
0359FBA8  a3 6f 70 97  bl       #0x11bba34
0359FBAC  28 00 80 52  mov      w8, #1
0359FBB0  88 0a 07 39  strb     w8, [x20, #0x1c2]
0359FBB4  e1 03 15 aa  mov      x1, x21
0359FBB8  fb 00 00 94  bl       #0x359ffa4 ; ToxicBird.FeatherSerialization$$CalculateOutputSize
0359FBBC  68 02 40 f9  ldr      x8, [x19]
0359FBC0  f4 03 00 2a  mov      w20, w0
0359FBC4  e0 03 08 aa  mov      x0, x8
0359FBC8  dc 6f 70 97  bl       #0x11bbb38
0359FBCC  a0 1e 00 b4  cbz      x0, #0x359ffa0
0359FBD0  b6 ee 00 90  adrp     x22, #0x5373000
0359FBD4  d6 d2 41 f9  ldr      x22, [x22, #0x3a0]
0359FBD8  e1 03 14 2a  mov      w1, w20
0359FBDC  e2 03 1f aa  mov      x2, xzr
0359FBE0  f3 03 00 aa  mov      x19, x0
0359FBE4  05 cb eb 97  bl       #0x30927f8 ; System.IO.MemoryStream$$.ctor
0359FBE8  c0 02 40 f9  ldr      x0, [x22]
0359FBEC  d3 6f 70 97  bl       #0x11bbb38
0359FBF0  80 1d 00 b4  cbz      x0, #0x359ffa0
0359FBF4  e1 03 13 aa  mov      x1, x19
0359FBF8  f4 03 00 aa  mov      x20, x0
0359FBFC  6d fe ff 97  bl       #0x359f5b0 ; ToxicBird.BigEndianBinaryWriter$$.ctor
0359FC00  15 1c 00 b4  cbz      x21, #0x359ff80
0359FC04  09 ee 00 90  adrp     x9, #0x535f000
0359FC08  29 bd 45 f9  ldr      x9, [x9, #0xb78]
0359FC0C  a8 02 40 f9  ldr      x8, [x21]
0359FC10  f6 ef 00 d0  adrp     x22, #0x539d000
0359FC14  2a 01 40 f9  ldr      x10, [x9]
0359FC18  09 b1 44 39  ldrb     w9, [x8, #0x12c]
0359FC1C  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FC20  d6 32 40 f9  ldr      x22, [x22, #0x60]
0359FC24  3f 01 0b 6b  cmp      w9, w11
0359FC28  c3 00 00 54  b.lo     #0x359fc40
0359FC2C  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FC30  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FC34  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FC38  7f 01 0a eb  cmp      x11, x10
0359FC3C  c0 0b 00 54  b.eq     #0x359fdb4
0359FC40  ca f1 00 f0  adrp     x10, #0x53da000
0359FC44  4a a9 40 f9  ldr      x10, [x10, #0x150]
0359FC48  4a 01 40 f9  ldr      x10, [x10]
0359FC4C  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FC50  3f 01 0b 6b  cmp      w9, w11
0359FC54  c3 00 00 54  b.lo     #0x359fc6c
0359FC58  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FC5C  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FC60  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FC64  7f 01 0a eb  cmp      x11, x10
0359FC68  20 0b 00 54  b.eq     #0x359fdcc
0359FC6C  aa f1 00 f0  adrp     x10, #0x53d6000
0359FC70  4a 09 44 f9  ldr      x10, [x10, #0x810]
0359FC74  4a 01 40 f9  ldr      x10, [x10]
0359FC78  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FC7C  3f 01 0b 6b  cmp      w9, w11
0359FC80  c3 00 00 54  b.lo     #0x359fc98
0359FC84  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FC88  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FC8C  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FC90  7f 01 0a eb  cmp      x11, x10
0359FC94  80 0a 00 54  b.eq     #0x359fde4
0359FC98  ca f1 00 b0  adrp     x10, #0x53d8000
0359FC9C  4a 5d 40 f9  ldr      x10, [x10, #0xb8]
0359FCA0  4a 01 40 f9  ldr      x10, [x10]
0359FCA4  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FCA8  3f 01 0b 6b  cmp      w9, w11
0359FCAC  c3 00 00 54  b.lo     #0x359fcc4
0359FCB0  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FCB4  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FCB8  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FCBC  7f 01 0a eb  cmp      x11, x10
0359FCC0  80 0a 00 54  b.eq     #0x359fe10
0359FCC4  2a ef 00 f0  adrp     x10, #0x5386000
0359FCC8  4a 09 41 f9  ldr      x10, [x10, #0x210]
0359FCCC  4a 01 40 f9  ldr      x10, [x10]
0359FCD0  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FCD4  3f 01 0b 6b  cmp      w9, w11
0359FCD8  c3 00 00 54  b.lo     #0x359fcf0
0359FCDC  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FCE0  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FCE4  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FCE8  7f 01 0a eb  cmp      x11, x10
0359FCEC  60 0c 00 54  b.eq     #0x359fe78
0359FCF0  ca f0 00 b0  adrp     x10, #0x53b8000
0359FCF4  4a d5 41 f9  ldr      x10, [x10, #0x3a8]
0359FCF8  4a 01 40 f9  ldr      x10, [x10]
0359FCFC  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FD00  3f 01 0b 6b  cmp      w9, w11
0359FD04  c3 00 00 54  b.lo     #0x359fd1c
0359FD08  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FD0C  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FD10  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FD14  7f 01 0a eb  cmp      x11, x10
0359FD18  40 10 00 54  b.eq     #0x359ff20
0359FD1C  0a f3 00 90  adrp     x10, #0x53ff000
0359FD20  4a 19 46 f9  ldr      x10, [x10, #0xc30]
0359FD24  4a 01 40 f9  ldr      x10, [x10]
0359FD28  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FD2C  3f 01 0b 6b  cmp      w9, w11
0359FD30  c3 00 00 54  b.lo     #0x359fd48
0359FD34  0c 65 40 f9  ldr      x12, [x8, #0xc8]
0359FD38  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
0359FD3C  6b 81 5f f8  ldur     x11, [x11, #-8]
0359FD40  7f 01 0a eb  cmp      x11, x10
0359FD44  a0 0f 00 54  b.eq     #0x359ff38
0359FD48  ca f0 00 f0  adrp     x10, #0x53ba000
0359FD4C  4a 45 43 f9  ldr      x10, [x10, #0x688]
0359FD50  4a 01 40 f9  ldr      x10, [x10]
0359FD54  4b b1 44 39  ldrb     w11, [x10, #0x12c]
0359FD58  3f 01 0b 6b  cmp      w9, w11
0359FD5C  23 11 00 54  b.lo     #0x359ff80
0359FD60  08 65 40 f9  ldr      x8, [x8, #0xc8]
0359FD64  08 0d 0b 8b  add      x8, x8, x11, lsl #3
0359FD68  08 81 5f f8  ldur     x8, [x8, #-8]
0359FD6C  1f 01 0a eb  cmp      x8, x10
0359FD70  81 10 00 54  b.ne     #0x359ff80
0359FD74  e0 03 1f aa  mov      x0, xzr
0359FD78  00 e3 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
0359FD7C  20 11 00 b4  cbz      x0, #0x359ffa0
0359FD80  08 00 40 f9  ldr      x8, [x0]
0359FD84  a1 0a 40 f9  ldr      x1, [x21, #0x10]
0359FD88  09 2d 41 f9  ldr      x9, [x8, #0x258]
0359FD8C  02 31 41 f9  ldr      x2, [x8, #0x260]
0359FD90  20 01 3f d6  blr      x9
0359FD94  c8 02 40 f9  ldr      x8, [x22]
0359FD98  f6 03 00 aa  mov      x22, x0
0359FD9C  09 e1 40 b9  ldr      w9, [x8, #0xe0]
0359FDA0  69 00 00 35  cbnz     w9, #0x359fdac
0359FDA4  e0 03 08 aa  mov      x0, x8
0359FDA8  5f 6f 70 97  bl       #0x11bbb24
0359FDAC  00 01 80 52  mov      w0, #8
0359FDB0  41 00 00 14  b        #0x359feb4
0359FDB4  c0 02 40 f9  ldr      x0, [x22]
0359FDB8  08 e0 40 b9  ldr      w8, [x0, #0xe0]
0359FDBC  48 00 00 35  cbnz     w8, #0x359fdc4
0359FDC0  59 6f 70 97  bl       #0x11bbb24
0359FDC4  20 00 80 52  mov      w0, #1
0359FDC8  0c 00 00 14  b        #0x359fdf8
0359FDCC  c0 02 40 f9  ldr      x0, [x22]
0359FDD0  08 e0 40 b9  ldr      w8, [x0, #0xe0]
0359FDD4  48 00 00 35  cbnz     w8, #0x359fddc
0359FDD8  53 6f 70 97  bl       #0x11bbb24
0359FDDC  40 00 80 52  mov      w0, #2
0359FDE0  06 00 00 14  b        #0x359fdf8
0359FDE4  c0 02 40 f9  ldr      x0, [x22]
0359FDE8  08 e0 40 b9  ldr      w8, [x0, #0xe0]
0359FDEC  48 00 00 35  cbnz     w8, #0x359fdf4
0359FDF0  4d 6f 70 97  bl       #0x11bbb24
0359FDF4  60 00 80 52  mov      w0, #3
0359FDF8  e1 03 1f aa  mov      x1, xzr
0359FDFC  08 ba 04 94  bl       #0x36ce61c ; System.Convert$$ToByte
0359FE00  88 02 40 f9  ldr      x8, [x20]
0359FE04  e1 03 00 2a  mov      w1, w0
0359FE08  09 89 5b a9  ldp      x9, x2, [x8, #0x1b8]
0359FE0C  5b 00 00 14  b        #0x359ff78
0359FE10  e0 03 1f aa  mov      x0, xzr
0359FE14  d9 e2 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
0359FE18  40 0c 00 b4  cbz      x0, #0x359ffa0
0359FE1C  08 00 40 f9  ldr      x8, [x0]
0359FE20  a1 0a 40 f9  ldr      x1, [x21, #0x10]
0359FE24  09 2d 41 f9  ldr      x9, [x8, #0x258]
0359FE28  02 31 41 f9  ldr      x2, [x8, #0x260]
0359FE2C  20 01 3f d6  blr      x9
0359FE30  c8 02 40 f9  ldr      x8, [x22]
0359FE34  f5 03 00 aa  mov      x21, x0
0359FE38  09 e1 40 b9  ldr      w9, [x8, #0xe0]
0359FE3C  69 00 00 35  cbnz     w9, #0x359fe48
0359FE40  e0 03 08 aa  mov      x0, x8
0359FE44  38 6f 70 97  bl       #0x11bbb24
0359FE48  80 00 80 52  mov      w0, #4
0359FE4C  e1 03 1f aa  mov      x1, xzr
0359FE50  f3 b9 04 94  bl       #0x36ce61c ; System.Convert$$ToByte
0359FE54  88 02 40 f9  ldr      x8, [x20]
0359FE58  e1 03 00 2a  mov      w1, w0
0359FE5C  e0 03 14 aa  mov      x0, x20
0359FE60  09 89 5b a9  ldp      x9, x2, [x8, #0x1b8]
0359FE64  20 01 3f d6  blr      x9
0359FE68  88 02 40 f9  ldr      x8, [x20]
0359FE6C  e0 03 14 aa  mov      x0, x20
0359FE70  e1 03 15 aa  mov      x1, x21
0359FE74  28 00 00 14  b        #0x359ff14
0359FE78  e0 03 1f aa  mov      x0, xzr
0359FE7C  bf e2 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
0359FE80  00 09 00 b4  cbz      x0, #0x359ffa0
0359FE84  08 00 40 f9  ldr      x8, [x0]
0359FE88  a1 0a 40 f9  ldr      x1, [x21, #0x10]
0359FE8C  09 2d 41 f9  ldr      x9, [x8, #0x258]
0359FE90  02 31 41 f9  ldr      x2, [x8, #0x260]
0359FE94  20 01 3f d6  blr      x9
0359FE98  c8 02 40 f9  ldr      x8, [x22]
0359FE9C  f6 03 00 aa  mov      x22, x0
0359FEA0  09 e1 40 b9  ldr      w9, [x8, #0xe0]
0359FEA4  69 00 00 35  cbnz     w9, #0x359feb0
0359FEA8  e0 03 08 aa  mov      x0, x8
0359FEAC  1e 6f 70 97  bl       #0x11bbb24
0359FEB0  a0 00 80 52  mov      w0, #5
0359FEB4  e1 03 1f aa  mov      x1, xzr
0359FEB8  d9 b9 04 94  bl       #0x36ce61c ; System.Convert$$ToByte
0359FEBC  88 02 40 f9  ldr      x8, [x20]
0359FEC0  e1 03 00 2a  mov      w1, w0
0359FEC4  e0 03 14 aa  mov      x0, x20
0359FEC8  09 89 5b a9  ldp      x9, x2, [x8, #0x1b8]
0359FECC  20 01 3f d6  blr      x9
0359FED0  96 06 00 b4  cbz      x22, #0x359ffa0
0359FED4  c0 1a 40 b9  ldr      w0, [x22, #0x18]
0359FED8  e1 03 1f aa  mov      x1, xzr
0359FEDC  d0 b9 04 94  bl       #0x36ce61c ; System.Convert$$ToByte
0359FEE0  88 02 40 f9  ldr      x8, [x20]
0359FEE4  e1 03 00 2a  mov      w1, w0
0359FEE8  e0 03 14 aa  mov      x0, x20
0359FEEC  09 89 5b a9  ldp      x9, x2, [x8, #0x1b8]
0359FEF0  20 01 3f d6  blr      x9
0359FEF4  88 02 40 f9  ldr      x8, [x20]
0359FEF8  e0 03 14 aa  mov      x0, x20
0359FEFC  e1 03 16 aa  mov      x1, x22
0359FF00  09 89 5c a9  ldp      x9, x2, [x8, #0x1c8]
0359FF04  20 01 3f d6  blr      x9
0359FF08  88 02 40 f9  ldr      x8, [x20]
0359FF0C  a1 0e 40 f9  ldr      x1, [x21, #0x18]
0359FF10  e0 03 14 aa  mov      x0, x20
0359FF14  09 89 5c a9  ldp      x9, x2, [x8, #0x1c8]
0359FF18  20 01 3f d6  blr      x9
0359FF1C  19 00 00 14  b        #0x359ff80
0359FF20  c0 02 40 f9  ldr      x0, [x22]
0359FF24  08 e0 40 b9  ldr      w8, [x0, #0xe0]
0359FF28  48 00 00 35  cbnz     w8, #0x359ff30
0359FF2C  fe 6e 70 97  bl       #0x11bbb24
0359FF30  c0 00 80 52  mov      w0, #6
0359FF34  06 00 00 14  b        #0x359ff4c
0359FF38  c0 02 40 f9  ldr      x0, [x22]
0359FF3C  08 e0 40 b9  ldr      w8, [x0, #0xe0]
0359FF40  48 00 00 35  cbnz     w8, #0x359ff48
0359FF44  f8 6e 70 97  bl       #0x11bbb24
0359FF48  e0 00 80 52  mov      w0, #7
0359FF4C  e1 03 1f aa  mov      x1, xzr
0359FF50  b3 b9 04 94  bl       #0x36ce61c ; System.Convert$$ToByte
0359FF54  88 02 40 f9  ldr      x8, [x20]
0359FF58  e1 03 00 2a  mov      w1, w0
0359FF5C  e0 03 14 aa  mov      x0, x20
0359FF60  09 89 5b a9  ldp      x9, x2, [x8, #0x1b8]
0359FF64  20 01 3f d6  blr      x9
0359FF68  88 02 40 f9  ldr      x8, [x20]
0359FF6C  a1 12 40 b9  ldr      w1, [x21, #0x10]
0359FF70  09 1d 41 f9  ldr      x9, [x8, #0x238]
0359FF74  02 21 41 f9  ldr      x2, [x8, #0x240]
0359FF78  e0 03 14 aa  mov      x0, x20
0359FF7C  20 01 3f d6  blr      x9
0359FF80  68 02 40 f9  ldr      x8, [x19]
0359FF84  e0 03 13 aa  mov      x0, x19
0359FF88  f3 7b 42 a9  ldp      x19, x30, [sp, #0x20]
0359FF8C  f5 53 41 a9  ldp      x21, x20, [sp, #0x10]
0359FF90  02 e5 41 f9  ldr      x2, [x8, #0x3c8]
0359FF94  01 e9 41 f9  ldr      x1, [x8, #0x3d0]
0359FF98  f6 07 43 f8  ldr      x22, [sp], #0x30
0359FF9C  40 00 1f d6  br       x2
0359FFA0  ea 6e 70 97  bl       #0x11bbb48

; FeatherSerialization.CalculateOutputSize: RVA 0x359FFA4 .. 0x35A0244 (exclusive)
0359FFA4  f4 0f 1e f8  str      x20, [sp, #-0x20]!
0359FFA8  f3 7b 01 a9  stp      x19, x30, [sp, #0x10]
0359FFAC  94 10 01 d0  adrp     x20, #0x57b1000
0359FFB0  88 12 47 39  ldrb     w8, [x20, #0x1c4]
0359FFB4  f3 03 01 aa  mov      x19, x1
0359FFB8  68 03 00 37  tbnz     w8, #0, #0x35a0024
0359FFBC  a0 f1 00 f0  adrp     x0, #0x53d6000
0359FFC0  00 08 44 f9  ldr      x0, [x0, #0x810]
0359FFC4  9c 6e 70 97  bl       #0x11bba34
0359FFC8  20 ef 00 f0  adrp     x0, #0x5386000
0359FFCC  00 08 41 f9  ldr      x0, [x0, #0x210]
0359FFD0  99 6e 70 97  bl       #0x11bba34
0359FFD4  c0 f0 00 b0  adrp     x0, #0x53b8000
0359FFD8  00 d4 41 f9  ldr      x0, [x0, #0x3a8]
0359FFDC  96 6e 70 97  bl       #0x11bba34
0359FFE0  00 f3 00 90  adrp     x0, #0x53ff000
0359FFE4  00 18 46 f9  ldr      x0, [x0, #0xc30]
0359FFE8  93 6e 70 97  bl       #0x11bba34
0359FFEC  00 ee 00 90  adrp     x0, #0x535f000
0359FFF0  00 bc 45 f9  ldr      x0, [x0, #0xb78]
0359FFF4  90 6e 70 97  bl       #0x11bba34
0359FFF8  c0 f1 00 f0  adrp     x0, #0x53da000
0359FFFC  00 a8 40 f9  ldr      x0, [x0, #0x150]
035A0000  8d 6e 70 97  bl       #0x11bba34
035A0004  c0 f1 00 90  adrp     x0, #0x53d8000
035A0008  00 5c 40 f9  ldr      x0, [x0, #0xb8]
035A000C  8a 6e 70 97  bl       #0x11bba34
035A0010  c0 f0 00 d0  adrp     x0, #0x53ba000
035A0014  00 44 43 f9  ldr      x0, [x0, #0x688]
035A0018  87 6e 70 97  bl       #0x11bba34
035A001C  28 00 80 52  mov      w8, #1
035A0020  88 12 07 39  strb     w8, [x20, #0x1c4]
035A0024  f3 0d 00 b4  cbz      x19, #0x35a01e0
035A0028  e9 ed 00 f0  adrp     x9, #0x535f000
035A002C  29 bd 45 f9  ldr      x9, [x9, #0xb78]
035A0030  68 02 40 f9  ldr      x8, [x19]
035A0034  2a 01 40 f9  ldr      x10, [x9]
035A0038  09 b1 44 39  ldrb     w9, [x8, #0x12c]
035A003C  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A0040  3f 01 0b 6b  cmp      w9, w11
035A0044  c3 00 00 54  b.lo     #0x35a005c
035A0048  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A004C  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A0050  6b 81 5f f8  ldur     x11, [x11, #-8]
035A0054  7f 01 0a eb  cmp      x11, x10
035A0058  e0 0a 00 54  b.eq     #0x35a01b4
035A005C  ca f1 00 d0  adrp     x10, #0x53da000
035A0060  4a a9 40 f9  ldr      x10, [x10, #0x150]
035A0064  4a 01 40 f9  ldr      x10, [x10]
035A0068  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A006C  3f 01 0b 6b  cmp      w9, w11
035A0070  c3 00 00 54  b.lo     #0x35a0088
035A0074  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A0078  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A007C  6b 81 5f f8  ldur     x11, [x11, #-8]
035A0080  7f 01 0a eb  cmp      x11, x10
035A0084  80 09 00 54  b.eq     #0x35a01b4
035A0088  aa f1 00 d0  adrp     x10, #0x53d6000
035A008C  4a 09 44 f9  ldr      x10, [x10, #0x810]
035A0090  4a 01 40 f9  ldr      x10, [x10]
035A0094  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A0098  3f 01 0b 6b  cmp      w9, w11
035A009C  c3 00 00 54  b.lo     #0x35a00b4
035A00A0  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A00A4  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A00A8  6b 81 5f f8  ldur     x11, [x11, #-8]
035A00AC  7f 01 0a eb  cmp      x11, x10
035A00B0  20 08 00 54  b.eq     #0x35a01b4
035A00B4  ca f1 00 90  adrp     x10, #0x53d8000
035A00B8  4a 5d 40 f9  ldr      x10, [x10, #0xb8]
035A00BC  4a 01 40 f9  ldr      x10, [x10]
035A00C0  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A00C4  3f 01 0b 6b  cmp      w9, w11
035A00C8  c3 00 00 54  b.lo     #0x35a00e0
035A00CC  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A00D0  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A00D4  6b 81 5f f8  ldur     x11, [x11, #-8]
035A00D8  7f 01 0a eb  cmp      x11, x10
035A00DC  40 07 00 54  b.eq     #0x35a01c4
035A00E0  2a ef 00 d0  adrp     x10, #0x5386000
035A00E4  4a 09 41 f9  ldr      x10, [x10, #0x210]
035A00E8  4a 01 40 f9  ldr      x10, [x10]
035A00EC  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A00F0  3f 01 0b 6b  cmp      w9, w11
035A00F4  c3 00 00 54  b.lo     #0x35a010c
035A00F8  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A00FC  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A0100  6b 81 5f f8  ldur     x11, [x11, #-8]
035A0104  7f 01 0a eb  cmp      x11, x10
035A0108  40 04 00 54  b.eq     #0x35a0190
035A010C  ca f0 00 90  adrp     x10, #0x53b8000
035A0110  4a d5 41 f9  ldr      x10, [x10, #0x3a8]
035A0114  4a 01 40 f9  ldr      x10, [x10]
035A0118  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A011C  3f 01 0b 6b  cmp      w9, w11
035A0120  c3 00 00 54  b.lo     #0x35a0138
035A0124  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A0128  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A012C  6b 81 5f f8  ldur     x11, [x11, #-8]
035A0130  7f 01 0a eb  cmp      x11, x10
035A0134  40 04 00 54  b.eq     #0x35a01bc
035A0138  ea f2 00 f0  adrp     x10, #0x53ff000
035A013C  4a 19 46 f9  ldr      x10, [x10, #0xc30]
035A0140  4a 01 40 f9  ldr      x10, [x10]
035A0144  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A0148  3f 01 0b 6b  cmp      w9, w11
035A014C  c3 00 00 54  b.lo     #0x35a0164
035A0150  0c 65 40 f9  ldr      x12, [x8, #0xc8]
035A0154  8b 0d 0b 8b  add      x11, x12, x11, lsl #3
035A0158  6b 81 5f f8  ldur     x11, [x11, #-8]
035A015C  7f 01 0a eb  cmp      x11, x10
035A0160  e0 02 00 54  b.eq     #0x35a01bc
035A0164  ca f0 00 d0  adrp     x10, #0x53ba000
035A0168  4a 45 43 f9  ldr      x10, [x10, #0x688]
035A016C  4a 01 40 f9  ldr      x10, [x10]
035A0170  4b b1 44 39  ldrb     w11, [x10, #0x12c]
035A0174  3f 01 0b 6b  cmp      w9, w11
035A0178  43 03 00 54  b.lo     #0x35a01e0
035A017C  08 65 40 f9  ldr      x8, [x8, #0xc8]
035A0180  08 0d 0b 8b  add      x8, x8, x11, lsl #3
035A0184  08 81 5f f8  ldur     x8, [x8, #-8]
035A0188  1f 01 0a eb  cmp      x8, x10
035A018C  a1 02 00 54  b.ne     #0x35a01e0
035A0190  68 0a 40 f9  ldr      x8, [x19, #0x10]
035A0194  68 05 00 b4  cbz      x8, #0x35a0240
035A0198  69 0e 40 f9  ldr      x9, [x19, #0x18]
035A019C  29 05 00 b4  cbz      x9, #0x35a0240
035A01A0  08 11 40 b9  ldr      w8, [x8, #0x10]
035A01A4  29 19 40 b9  ldr      w9, [x9, #0x18]
035A01A8  08 01 09 0b  add      w8, w8, w9
035A01AC  00 09 00 11  add      w0, w8, #2
035A01B0  09 00 00 14  b        #0x35a01d4
035A01B4  20 00 80 52  mov      w0, #1
035A01B8  07 00 00 14  b        #0x35a01d4
035A01BC  a0 00 80 52  mov      w0, #5
035A01C0  05 00 00 14  b        #0x35a01d4
035A01C4  68 0a 40 f9  ldr      x8, [x19, #0x10]
035A01C8  c8 03 00 b4  cbz      x8, #0x35a0240
035A01CC  08 11 40 b9  ldr      w8, [x8, #0x10]
035A01D0  00 05 00 11  add      w0, w8, #1
035A01D4  f3 7b 41 a9  ldp      x19, x30, [sp, #0x10]
035A01D8  f4 07 42 f8  ldr      x20, [sp], #0x20
035A01DC  c0 03 5f d6  ret      
035A01E0  00 f0 00 90  adrp     x0, #0x53a0000
035A01E4  00 08 40 f9  ldr      x0, [x0, #0x10]
035A01E8  14 6e 70 97  bl       #0x11bba38
035A01EC  53 6e 70 97  bl       #0x11bbb38
035A01F0  f3 03 00 aa  mov      x19, x0
035A01F4  a6 d2 62 97  bl       #0xe54c8c
035A01F8  40 f3 00 f0  adrp     x0, #0x540b000
035A01FC  00 d8 47 f9  ldr      x0, [x0, #0xfb0]
035A0200  0e 6e 70 97  bl       #0x11bba38
035A0204  f4 03 00 aa  mov      x20, x0
035A0208  20 f0 00 90  adrp     x0, #0x53a4000
035A020C  00 68 47 f9  ldr      x0, [x0, #0xed0]
035A0210  0a 6e 70 97  bl       #0x11bba38
035A0214  e2 03 00 aa  mov      x2, x0
035A0218  e0 03 13 aa  mov      x0, x19
035A021C  e1 03 14 aa  mov      x1, x20
035A0220  e3 03 1f aa  mov      x3, xzr
035A0224  75 73 04 94  bl       #0x36bcff8 ; System.ArgumentException$$.ctor
035A0228  a0 f2 00 f0  adrp     x0, #0x53f7000
035A022C  00 48 45 f9  ldr      x0, [x0, #0xa90]
035A0230  02 6e 70 97  bl       #0x11bba38
035A0234  e1 03 00 aa  mov      x1, x0
035A0238  e0 03 13 aa  mov      x0, x19
035A023C  35 6e 70 97  bl       #0x11bbb10
035A0240  42 6e 70 97  bl       #0x11bbb48

; FeatherSerialization.Deserialize: RVA 0x35A0244 .. 0x35A0BC4 (exclusive)
035A0244  f9 63 bc a9  stp      x25, x24, [sp, #-0x40]!
035A0248  f7 5b 01 a9  stp      x23, x22, [sp, #0x10]
035A024C  f5 53 02 a9  stp      x21, x20, [sp, #0x20]
035A0250  f3 7b 03 a9  stp      x19, x30, [sp, #0x30]
035A0254  94 10 01 b0  adrp     x20, #0x57b1000
035A0258  d6 f2 00 f0  adrp     x22, #0x53fb000
035A025C  88 0e 47 39  ldrb     w8, [x20, #0x1c3]
035A0260  d6 0a 44 f9  ldr      x22, [x22, #0x810]
035A0264  f3 03 01 aa  mov      x19, x1
035A0268  f5 03 00 aa  mov      x21, x0
035A026C  08 09 00 37  tbnz     w8, #0, #0x35a038c
035A0270  a0 f2 00 d0  adrp     x0, #0x53f6000
035A0274  00 70 45 f9  ldr      x0, [x0, #0xae0]
035A0278  ef 6d 70 97  bl       #0x11bba34
035A027C  00 ef 00 f0  adrp     x0, #0x5383000
035A0280  00 9c 45 f9  ldr      x0, [x0, #0xb38]
035A0284  ec 6d 70 97  bl       #0x11bba34
035A0288  40 f2 00 90  adrp     x0, #0x53e8000
035A028C  00 d0 47 f9  ldr      x0, [x0, #0xfa0]
035A0290  e9 6d 70 97  bl       #0x11bba34
035A0294  00 f0 00 90  adrp     x0, #0x53a0000
035A0298  00 bc 41 f9  ldr      x0, [x0, #0x378]
035A029C  e6 6d 70 97  bl       #0x11bba34
035A02A0  a0 ee 00 d0  adrp     x0, #0x5376000
035A02A4  00 c4 40 f9  ldr      x0, [x0, #0x188]
035A02A8  e3 6d 70 97  bl       #0x11bba34
035A02AC  e0 ef 00 b0  adrp     x0, #0x539d000
035A02B0  00 30 40 f9  ldr      x0, [x0, #0x60]
035A02B4  e0 6d 70 97  bl       #0x11bba34
035A02B8  80 ef 00 d0  adrp     x0, #0x5392000
035A02BC  00 98 44 f9  ldr      x0, [x0, #0x930]
035A02C0  dd 6d 70 97  bl       #0x11bba34
035A02C4  80 f2 00 90  adrp     x0, #0x53f0000
035A02C8  00 74 42 f9  ldr      x0, [x0, #0x4e8]
035A02CC  da 6d 70 97  bl       #0x11bba34
035A02D0  00 ef 00 f0  adrp     x0, #0x5383000
035A02D4  00 f0 40 f9  ldr      x0, [x0, #0x1e0]
035A02D8  d7 6d 70 97  bl       #0x11bba34
035A02DC  00 f3 00 f0  adrp     x0, #0x5403000
035A02E0  00 c8 41 f9  ldr      x0, [x0, #0x390]
035A02E4  d4 6d 70 97  bl       #0x11bba34
035A02E8  c0 ee 00 90  adrp     x0, #0x5378000
035A02EC  00 14 46 f9  ldr      x0, [x0, #0xc28]
035A02F0  d1 6d 70 97  bl       #0x11bba34
035A02F4  e0 f0 00 d0  adrp     x0, #0x53be000
035A02F8  00 a4 43 f9  ldr      x0, [x0, #0x748]
035A02FC  ce 6d 70 97  bl       #0x11bba34
035A0300  20 f2 00 d0  adrp     x0, #0x53e6000
035A0304  00 0c 41 f9  ldr      x0, [x0, #0x218]
035A0308  cb 6d 70 97  bl       #0x11bba34
035A030C  40 f1 00 b0  adrp     x0, #0x53c9000
035A0310  00 4c 43 f9  ldr      x0, [x0, #0x698]
035A0314  c8 6d 70 97  bl       #0x11bba34
035A0318  20 f1 00 d0  adrp     x0, #0x53c6000
035A031C  00 18 41 f9  ldr      x0, [x0, #0x230]
035A0320  c5 6d 70 97  bl       #0x11bba34
035A0324  c0 f2 00 f0  adrp     x0, #0x53fb000
035A0328  00 08 44 f9  ldr      x0, [x0, #0x810]
035A032C  c2 6d 70 97  bl       #0x11bba34
035A0330  80 f0 00 f0  adrp     x0, #0x53b3000
035A0334  00 28 43 f9  ldr      x0, [x0, #0x650]
035A0338  bf 6d 70 97  bl       #0x11bba34
035A033C  20 ef 00 90  adrp     x0, #0x5384000
035A0340  00 a4 42 f9  ldr      x0, [x0, #0x548]
035A0344  bc 6d 70 97  bl       #0x11bba34
035A0348  a0 ee 00 b0  adrp     x0, #0x5375000
035A034C  00 e0 40 f9  ldr      x0, [x0, #0x1c0]
035A0350  b9 6d 70 97  bl       #0x11bba34
035A0354  c0 ef 00 90  adrp     x0, #0x5398000
035A0358  00 e4 46 f9  ldr      x0, [x0, #0xdc8]
035A035C  b6 6d 70 97  bl       #0x11bba34
035A0360  40 ef 00 b0  adrp     x0, #0x5389000
035A0364  00 88 47 f9  ldr      x0, [x0, #0xf10]
035A0368  b3 6d 70 97  bl       #0x11bba34
035A036C  e0 f1 00 b0  adrp     x0, #0x53dd000
035A0370  00 6c 47 f9  ldr      x0, [x0, #0xed8]
035A0374  b0 6d 70 97  bl       #0x11bba34
035A0378  c0 ef 00 f0  adrp     x0, #0x539b000
035A037C  00 e0 40 f9  ldr      x0, [x0, #0x1c0]
035A0380  ad 6d 70 97  bl       #0x11bba34
035A0384  28 00 80 52  mov      w8, #1
035A0388  88 0e 07 39  strb     w8, [x20, #0x1c3]
035A038C  c0 02 40 f9  ldr      x0, [x22]
035A0390  ea 6d 70 97  bl       #0x11bbb38
035A0394  60 3e 00 b4  cbz      x0, #0x35a0b60
035A0398  16 ef 00 f0  adrp     x22, #0x5383000
035A039C  d6 9e 45 f9  ldr      x22, [x22, #0xb38]
035A03A0  e1 03 13 aa  mov      x1, x19
035A03A4  e2 03 1f aa  mov      x2, xzr
035A03A8  f4 03 00 aa  mov      x20, x0
035A03AC  6e c9 eb 97  bl       #0x3092964 ; System.IO.MemoryStream$$.ctor
035A03B0  c0 02 40 f9  ldr      x0, [x22]
035A03B4  e1 6d 70 97  bl       #0x11bbb38
035A03B8  40 3d 00 b4  cbz      x0, #0x35a0b60
035A03BC  e1 03 14 aa  mov      x1, x20
035A03C0  e2 03 1f aa  mov      x2, xzr
035A03C4  f3 03 00 aa  mov      x19, x0
035A03C8  7d da ea 97  bl       #0x3056dbc ; System.IO.BinaryReader$$.ctor
035A03CC  68 02 40 f9  ldr      x8, [x19]
035A03D0  e0 03 13 aa  mov      x0, x19
035A03D4  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A03D8  20 01 3f d6  blr      x9
035A03DC  08 1c 00 12  and      w8, w0, #0xff
035A03E0  08 05 00 51  sub      w8, w8, #1
035A03E4  1f 31 00 71  cmp      w8, #0xc
035A03E8  e8 3b 00 54  b.hi     #0x35a0b64
035A03EC  a9 54 00 90  adrp     x9, #0x4034000
035A03F0  56 f2 00 90  adrp     x22, #0x53e8000
035A03F4  29 21 26 91  add      x9, x9, #0x988
035A03F8  f9 ef 00 b0  adrp     x25, #0x539d000
035A03FC  d6 d2 47 f9  ldr      x22, [x22, #0xfa0]
035A0400  aa 00 00 10  adr      x10, #0x35a0414
035A0404  2b 79 68 78  ldrh     w11, [x9, x8, lsl #1]
035A0408  4a 09 0b 8b  add      x10, x10, x11, lsl #2
035A040C  39 33 40 f9  ldr      x25, [x25, #0x60]
035A0410  40 01 1f d6  br       x10
035A0414  48 ef 00 b0  adrp     x8, #0x5389000
035A0418  08 89 47 f9  ldr      x8, [x8, #0xf10]
035A041C  dd 00 00 14  b        #0x35a0790
035A0420  68 02 40 f9  ldr      x8, [x19]
035A0424  34 ef 00 90  adrp     x20, #0x5384000
035A0428  09 15 41 f9  ldr      x9, [x8, #0x228]
035A042C  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0430  94 a6 42 f9  ldr      x20, [x20, #0x548]
035A0434  a1 01 00 14  b        #0x35a0ab8
035A0438  68 02 40 f9  ldr      x8, [x19]
035A043C  e0 03 13 aa  mov      x0, x19
035A0440  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A0444  20 01 3f d6  blr      x9
035A0448  c8 02 40 f9  ldr      x8, [x22]
035A044C  15 1c 00 12  and      w21, w0, #0xff
035A0450  e1 03 15 2a  mov      w1, w21
035A0454  e0 03 08 aa  mov      x0, x8
035A0458  8e 6d 70 97  bl       #0x11bba90
035A045C  68 02 40 f9  ldr      x8, [x19]
035A0460  f6 03 00 aa  mov      x22, x0
035A0464  e0 03 13 aa  mov      x0, x19
035A0468  e1 03 16 aa  mov      x1, x22
035A046C  09 5d 41 f9  ldr      x9, [x8, #0x2b8]
035A0470  04 61 41 f9  ldr      x4, [x8, #0x2c0]
035A0474  e2 03 1f 2a  mov      w2, wzr
035A0478  e3 03 15 2a  mov      w3, w21
035A047C  20 01 3f d6  blr      x9
035A0480  88 02 40 f9  ldr      x8, [x20]
035A0484  e0 03 14 aa  mov      x0, x20
035A0488  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A048C  20 01 3f d6  blr      x9
035A0490  88 02 40 f9  ldr      x8, [x20]
035A0494  f7 03 00 aa  mov      x23, x0
035A0498  e0 03 14 aa  mov      x0, x20
035A049C  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A04A0  20 01 3f d6  blr      x9
035A04A4  28 03 40 f9  ldr      x8, [x25]
035A04A8  f4 03 00 aa  mov      x20, x0
035A04AC  09 e1 40 b9  ldr      w9, [x8, #0xe0]
035A04B0  69 00 00 35  cbnz     w9, #0x35a04bc
035A04B4  e0 03 08 aa  mov      x0, x8
035A04B8  9b 6d 70 97  bl       #0x11bbb24
035A04BC  e0 02 14 cb  sub      x0, x23, x20
035A04C0  e1 03 1f aa  mov      x1, xzr
035A04C4  46 bc 04 94  bl       #0x36cf5dc ; System.Convert$$ToInt32
035A04C8  68 02 40 f9  ldr      x8, [x19]
035A04CC  e1 03 00 2a  mov      w1, w0
035A04D0  e0 03 13 aa  mov      x0, x19
035A04D4  09 65 41 f9  ldr      x9, [x8, #0x2c8]
035A04D8  02 69 41 f9  ldr      x2, [x8, #0x2d0]
035A04DC  20 01 3f d6  blr      x9
035A04E0  f4 03 00 aa  mov      x20, x0
035A04E4  e0 03 1f aa  mov      x0, xzr
035A04E8  24 e1 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
035A04EC  a0 33 00 b4  cbz      x0, #0x35a0b60
035A04F0  08 00 40 f9  ldr      x8, [x0]
035A04F4  93 ef 00 d0  adrp     x19, #0x5392000
035A04F8  e1 03 16 aa  mov      x1, x22
035A04FC  e2 03 1f 2a  mov      w2, wzr
035A0500  09 c5 41 f9  ldr      x9, [x8, #0x388]
035A0504  04 c9 41 f9  ldr      x4, [x8, #0x390]
035A0508  73 9a 44 f9  ldr      x19, [x19, #0x930]
035A050C  e3 03 15 2a  mov      w3, w21
035A0510  20 01 3f d6  blr      x9
035A0514  68 02 40 f9  ldr      x8, [x19]
035A0518  f5 03 00 aa  mov      x21, x0
035A051C  e0 03 08 aa  mov      x0, x8
035A0520  86 6d 70 97  bl       #0x11bbb38
035A0524  e0 31 00 b4  cbz      x0, #0x35a0b60
035A0528  e1 03 15 aa  mov      x1, x21
035A052C  e2 03 14 aa  mov      x2, x20
035A0530  f3 03 00 aa  mov      x19, x0
035A0534  c6 fc ff 97  bl       #0x359f84c ; ToxicBird.IncomingMessage.Event$$.ctor
035A0538  84 01 00 14  b        #0x35a0b48
035A053C  28 f1 00 d0  adrp     x8, #0x53c6000
035A0540  08 19 41 f9  ldr      x8, [x8, #0x230]
035A0544  00 01 40 f9  ldr      x0, [x8]
035A0548  7c 6d 70 97  bl       #0x11bbb38
035A054C  a0 30 00 b4  cbz      x0, #0x35a0b60
035A0550  28 f2 00 d0  adrp     x8, #0x53e6000
035A0554  08 0d 41 f9  ldr      x8, [x8, #0x218]
035A0558  f6 03 00 aa  mov      x22, x0
035A055C  01 01 40 f9  ldr      x1, [x8]
035A0560  24 36 df 97  bl       #0x2d6ddf0 ; System.Collections.Generic.List<object>$$.ctor
035A0564  88 02 40 f9  ldr      x8, [x20]
035A0568  e0 03 14 aa  mov      x0, x20
035A056C  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A0570  20 01 3f d6  blr      x9
035A0574  88 02 40 f9  ldr      x8, [x20]
035A0578  f7 03 00 aa  mov      x23, x0
035A057C  e0 03 14 aa  mov      x0, x20
035A0580  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A0584  20 01 3f d6  blr      x9
035A0588  ff 02 00 eb  cmp      x23, x0
035A058C  60 06 00 54  b.eq     #0x35a0658
035A0590  d8 ee 00 90  adrp     x24, #0x5378000
035A0594  18 17 46 f9  ldr      x24, [x24, #0xc28]
035A0598  68 02 40 f9  ldr      x8, [x19]
035A059C  e0 03 13 aa  mov      x0, x19
035A05A0  09 15 41 f9  ldr      x9, [x8, #0x228]
035A05A4  01 19 41 f9  ldr      x1, [x8, #0x230]
035A05A8  20 01 3f d6  blr      x9
035A05AC  68 02 40 f9  ldr      x8, [x19]
035A05B0  e1 03 00 2a  mov      w1, w0
035A05B4  e0 03 13 aa  mov      x0, x19
035A05B8  09 65 41 f9  ldr      x9, [x8, #0x2c8]
035A05BC  02 69 41 f9  ldr      x2, [x8, #0x2d0]
035A05C0  20 01 3f d6  blr      x9
035A05C4  e1 03 00 aa  mov      x1, x0
035A05C8  e0 03 15 aa  mov      x0, x21
035A05CC  1e ff ff 97  bl       #0x35a0244 ; ToxicBird.FeatherSerialization$$Deserialize
035A05D0  ca 1e 40 b9  ldr      w10, [x22, #0x1c]
035A05D4  c8 0a 40 f9  ldr      x8, [x22, #0x10]
035A05D8  09 03 40 f9  ldr      x9, [x24]
035A05DC  4a 05 00 11  add      w10, w10, #1
035A05E0  ca 1e 00 b9  str      w10, [x22, #0x1c]
035A05E4  e8 2b 00 b4  cbz      x8, #0x35a0b60
035A05E8  ca 1a 80 b9  ldrsw    x10, [x22, #0x18]
035A05EC  0b 19 40 b9  ldr      w11, [x8, #0x18]
035A05F0  e1 03 00 aa  mov      x1, x0
035A05F4  5f 01 0b 6b  cmp      w10, w11
035A05F8  e2 00 00 54  b.hs     #0x35a0614
035A05FC  49 05 00 11  add      w9, w10, #1
035A0600  00 0d 0a 8b  add      x0, x8, x10, lsl #3
035A0604  c9 1a 00 b9  str      w9, [x22, #0x18]
035A0608  01 0c 02 f8  str      x1, [x0, #0x20]!
035A060C  f7 6c 70 97  bl       #0x11bb9e8
035A0610  07 00 00 14  b        #0x35a062c
035A0614  28 11 40 f9  ldr      x8, [x9, #0x20]
035A0618  e0 03 16 aa  mov      x0, x22
035A061C  08 61 40 f9  ldr      x8, [x8, #0xc0]
035A0620  02 2d 40 f9  ldr      x2, [x8, #0x58]
035A0624  48 04 40 f9  ldr      x8, [x2, #8]
035A0628  00 01 3f d6  blr      x8
035A062C  88 02 40 f9  ldr      x8, [x20]
035A0630  e0 03 14 aa  mov      x0, x20
035A0634  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A0638  20 01 3f d6  blr      x9
035A063C  88 02 40 f9  ldr      x8, [x20]
035A0640  f7 03 00 aa  mov      x23, x0
035A0644  e0 03 14 aa  mov      x0, x20
035A0648  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A064C  20 01 3f d6  blr      x9
035A0650  ff 02 00 eb  cmp      x23, x0
035A0654  21 fa ff 54  b.ne     #0x35a0598
035A0658  a8 f2 00 d0  adrp     x8, #0x53f6000
035A065C  08 71 45 f9  ldr      x8, [x8, #0xae0]
035A0660  00 01 40 f9  ldr      x0, [x8]
035A0664  35 6d 70 97  bl       #0x11bbb38
035A0668  c0 27 00 b4  cbz      x0, #0x35a0b60
035A066C  e1 03 1f aa  mov      x1, xzr
035A0670  f3 03 00 aa  mov      x19, x0
035A0674  bc ee 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A0678  e0 03 13 aa  mov      x0, x19
035A067C  16 0c 01 f8  str      x22, [x0, #0x10]!
035A0680  e1 03 16 aa  mov      x1, x22
035A0684  30 01 00 14  b        #0x35a0b44
035A0688  68 02 40 f9  ldr      x8, [x19]
035A068C  e0 03 13 aa  mov      x0, x19
035A0690  09 15 41 f9  ldr      x9, [x8, #0x228]
035A0694  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0698  20 01 3f d6  blr      x9
035A069C  88 02 40 f9  ldr      x8, [x20]
035A06A0  f5 03 00 2a  mov      w21, w0
035A06A4  e0 03 14 aa  mov      x0, x20
035A06A8  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A06AC  20 01 3f d6  blr      x9
035A06B0  88 02 40 f9  ldr      x8, [x20]
035A06B4  f6 03 00 aa  mov      x22, x0
035A06B8  e0 03 14 aa  mov      x0, x20
035A06BC  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A06C0  20 01 3f d6  blr      x9
035A06C4  28 03 40 f9  ldr      x8, [x25]
035A06C8  f4 03 00 aa  mov      x20, x0
035A06CC  09 e1 40 b9  ldr      w9, [x8, #0xe0]
035A06D0  69 00 00 35  cbnz     w9, #0x35a06dc
035A06D4  e0 03 08 aa  mov      x0, x8
035A06D8  13 6d 70 97  bl       #0x11bbb24
035A06DC  c0 02 14 cb  sub      x0, x22, x20
035A06E0  e1 03 1f aa  mov      x1, xzr
035A06E4  be bb 04 94  bl       #0x36cf5dc ; System.Convert$$ToInt32
035A06E8  f4 03 00 2a  mov      w20, w0
035A06EC  e0 03 1f aa  mov      x0, xzr
035A06F0  a2 e0 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
035A06F4  68 02 40 f9  ldr      x8, [x19]
035A06F8  f6 03 00 aa  mov      x22, x0
035A06FC  e0 03 13 aa  mov      x0, x19
035A0700  e1 03 14 2a  mov      w1, w20
035A0704  09 65 41 f9  ldr      x9, [x8, #0x2c8]
035A0708  02 69 41 f9  ldr      x2, [x8, #0x2d0]
035A070C  20 01 3f d6  blr      x9
035A0710  96 22 00 b4  cbz      x22, #0x35a0b60
035A0714  c8 02 40 f9  ldr      x8, [x22]
035A0718  13 f0 00 90  adrp     x19, #0x53a0000
035A071C  e1 03 00 aa  mov      x1, x0
035A0720  e0 03 16 aa  mov      x0, x22
035A0724  09 c5 41 f9  ldr      x9, [x8, #0x388]
035A0728  04 c9 41 f9  ldr      x4, [x8, #0x390]
035A072C  73 be 41 f9  ldr      x19, [x19, #0x378]
035A0730  e2 03 1f 2a  mov      w2, wzr
035A0734  e3 03 14 2a  mov      w3, w20
035A0738  20 01 3f d6  blr      x9
035A073C  68 02 40 f9  ldr      x8, [x19]
035A0740  f4 03 00 aa  mov      x20, x0
035A0744  e0 03 08 aa  mov      x0, x8
035A0748  fc 6c 70 97  bl       #0x11bbb38
035A074C  a0 20 00 b4  cbz      x0, #0x35a0b60
035A0750  e1 03 1f aa  mov      x1, xzr
035A0754  f3 03 00 aa  mov      x19, x0
035A0758  83 ee 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A075C  e0 03 13 aa  mov      x0, x19
035A0760  14 8c 01 f8  str      x20, [x0, #0x18]!
035A0764  15 80 1f b8  stur     w21, [x0, #-8]
035A0768  e1 03 14 aa  mov      x1, x20
035A076C  f6 00 00 14  b        #0x35a0b44
035A0770  68 02 40 f9  ldr      x8, [x19]
035A0774  d5 ef 00 90  adrp     x21, #0x5398000
035A0778  09 15 41 f9  ldr      x9, [x8, #0x228]
035A077C  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0780  b5 e6 46 f9  ldr      x21, [x21, #0xdc8]
035A0784  b6 00 00 14  b        #0x35a0a5c
035A0788  e8 f1 00 b0  adrp     x8, #0x53dd000
035A078C  08 6d 47 f9  ldr      x8, [x8, #0xed8]
035A0790  00 01 40 f9  ldr      x0, [x8]
035A0794  e9 6c 70 97  bl       #0x11bbb38
035A0798  40 1e 00 b4  cbz      x0, #0x35a0b60
035A079C  e1 03 1f aa  mov      x1, xzr
035A07A0  f3 03 00 aa  mov      x19, x0
035A07A4  70 ee 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A07A8  e8 00 00 14  b        #0x35a0b48
035A07AC  68 02 40 f9  ldr      x8, [x19]
035A07B0  b4 ee 00 d0  adrp     x20, #0x5376000
035A07B4  e0 03 13 aa  mov      x0, x19
035A07B8  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A07BC  94 c6 40 f9  ldr      x20, [x20, #0x188]
035A07C0  20 01 3f d6  blr      x9
035A07C4  88 02 40 f9  ldr      x8, [x20]
035A07C8  f4 03 00 2a  mov      w20, w0
035A07CC  e0 03 08 aa  mov      x0, x8
035A07D0  da 6c 70 97  bl       #0x11bbb38
035A07D4  60 1c 00 b4  cbz      x0, #0x35a0b60
035A07D8  f3 03 00 aa  mov      x19, x0
035A07DC  94 1e 00 12  and      w20, w20, #0xff
035A07E0  be 00 00 14  b        #0x35a0ad8
035A07E4  68 02 40 f9  ldr      x8, [x19]
035A07E8  e0 03 13 aa  mov      x0, x19
035A07EC  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A07F0  20 01 3f d6  blr      x9
035A07F4  c8 02 40 f9  ldr      x8, [x22]
035A07F8  15 1c 00 12  and      w21, w0, #0xff
035A07FC  e1 03 15 2a  mov      w1, w21
035A0800  e0 03 08 aa  mov      x0, x8
035A0804  a3 6c 70 97  bl       #0x11bba90
035A0808  68 02 40 f9  ldr      x8, [x19]
035A080C  f6 03 00 aa  mov      x22, x0
035A0810  e0 03 13 aa  mov      x0, x19
035A0814  e1 03 16 aa  mov      x1, x22
035A0818  09 5d 41 f9  ldr      x9, [x8, #0x2b8]
035A081C  04 61 41 f9  ldr      x4, [x8, #0x2c0]
035A0820  e2 03 1f 2a  mov      w2, wzr
035A0824  e3 03 15 2a  mov      w3, w21
035A0828  20 01 3f d6  blr      x9
035A082C  88 02 40 f9  ldr      x8, [x20]
035A0830  e0 03 14 aa  mov      x0, x20
035A0834  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A0838  20 01 3f d6  blr      x9
035A083C  88 02 40 f9  ldr      x8, [x20]
035A0840  f7 03 00 aa  mov      x23, x0
035A0844  e0 03 14 aa  mov      x0, x20
035A0848  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A084C  20 01 3f d6  blr      x9
035A0850  28 03 40 f9  ldr      x8, [x25]
035A0854  f4 03 00 aa  mov      x20, x0
035A0858  09 e1 40 b9  ldr      w9, [x8, #0xe0]
035A085C  69 00 00 35  cbnz     w9, #0x35a0868
035A0860  e0 03 08 aa  mov      x0, x8
035A0864  b0 6c 70 97  bl       #0x11bbb24
035A0868  e0 02 14 cb  sub      x0, x23, x20
035A086C  e1 03 1f aa  mov      x1, xzr
035A0870  5b bb 04 94  bl       #0x36cf5dc ; System.Convert$$ToInt32
035A0874  68 02 40 f9  ldr      x8, [x19]
035A0878  e1 03 00 2a  mov      w1, w0
035A087C  e0 03 13 aa  mov      x0, x19
035A0880  09 65 41 f9  ldr      x9, [x8, #0x2c8]
035A0884  02 69 41 f9  ldr      x2, [x8, #0x2d0]
035A0888  20 01 3f d6  blr      x9
035A088C  f4 03 00 aa  mov      x20, x0
035A0890  e0 03 1f aa  mov      x0, xzr
035A0894  39 e0 c9 97  bl       #0x2818978 ; System.Text.Encoding$$get_ASCII
035A0898  40 16 00 b4  cbz      x0, #0x35a0b60
035A089C  08 00 40 f9  ldr      x8, [x0]
035A08A0  d3 ef 00 f0  adrp     x19, #0x539b000
035A08A4  e1 03 16 aa  mov      x1, x22
035A08A8  e2 03 1f 2a  mov      w2, wzr
035A08AC  09 c5 41 f9  ldr      x9, [x8, #0x388]
035A08B0  04 c9 41 f9  ldr      x4, [x8, #0x390]
035A08B4  73 e2 40 f9  ldr      x19, [x19, #0x1c0]
035A08B8  e3 03 15 2a  mov      w3, w21
035A08BC  20 01 3f d6  blr      x9
035A08C0  68 02 40 f9  ldr      x8, [x19]
035A08C4  f5 03 00 aa  mov      x21, x0
035A08C8  e0 03 08 aa  mov      x0, x8
035A08CC  9b 6c 70 97  bl       #0x11bbb38
035A08D0  80 14 00 b4  cbz      x0, #0x35a0b60
035A08D4  e1 03 15 aa  mov      x1, x21
035A08D8  e2 03 14 aa  mov      x2, x20
035A08DC  f3 03 00 aa  mov      x19, x0
035A08E0  0a fc ff 97  bl       #0x359f908 ; ToxicBird.IncomingMessage.RoomEvent$$.ctor
035A08E4  99 00 00 14  b        #0x35a0b48
035A08E8  68 02 40 f9  ldr      x8, [x19]
035A08EC  55 f1 00 b0  adrp     x21, #0x53c9000
035A08F0  e0 03 13 aa  mov      x0, x19
035A08F4  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A08F8  b5 4e 43 f9  ldr      x21, [x21, #0x698]
035A08FC  20 01 3f d6  blr      x9
035A0900  a8 02 40 f9  ldr      x8, [x21]
035A0904  f6 03 00 2a  mov      w22, w0
035A0908  e0 03 08 aa  mov      x0, x8
035A090C  8b 6c 70 97  bl       #0x11bbb38
035A0910  80 12 00 b4  cbz      x0, #0x35a0b60
035A0914  e8 f0 00 d0  adrp     x8, #0x53be000
035A0918  08 a5 43 f9  ldr      x8, [x8, #0x748]
035A091C  f5 03 00 aa  mov      x21, x0
035A0920  d7 1e 00 12  and      w23, w22, #0xff
035A0924  01 01 40 f9  ldr      x1, [x8]
035A0928  ce 0d ef 97  bl       #0x3164060 ; System.Collections.Generic.List<int>$$.ctor
035A092C  68 02 40 f9  ldr      x8, [x19]
035A0930  ff 06 00 71  cmp      w23, #1
035A0934  c1 0d 00 54  b.ne     #0x35a0aec
035A0938  09 15 41 f9  ldr      x9, [x8, #0x228]
035A093C  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0940  e0 03 13 aa  mov      x0, x19
035A0944  20 01 3f d6  blr      x9
035A0948  88 02 40 f9  ldr      x8, [x20]
035A094C  f7 03 00 2a  mov      w23, w0
035A0950  e0 03 14 aa  mov      x0, x20
035A0954  09 85 5e a9  ldp      x9, x1, [x8, #0x1e8]
035A0958  20 01 3f d6  blr      x9
035A095C  88 02 40 f9  ldr      x8, [x20]
035A0960  f8 03 00 aa  mov      x24, x0
035A0964  e0 03 14 aa  mov      x0, x20
035A0968  09 85 5f a9  ldp      x9, x1, [x8, #0x1f8]
035A096C  20 01 3f d6  blr      x9
035A0970  28 03 40 f9  ldr      x8, [x25]
035A0974  f4 03 00 aa  mov      x20, x0
035A0978  09 e1 40 b9  ldr      w9, [x8, #0xe0]
035A097C  69 00 00 35  cbnz     w9, #0x35a0988
035A0980  e0 03 08 aa  mov      x0, x8
035A0984  68 6c 70 97  bl       #0x11bbb24
035A0988  00 03 14 cb  sub      x0, x24, x20
035A098C  e1 03 1f aa  mov      x1, xzr
035A0990  13 bb 04 94  bl       #0x36cf5dc ; System.Convert$$ToInt32
035A0994  08 0c 00 11  add      w8, w0, #3
035A0998  1f 00 00 71  cmp      w0, #0
035A099C  08 b1 80 1a  csel     w8, w8, w0, lt
035A09A0  1f 10 00 71  cmp      w0, #4
035A09A4  2b 04 00 54  b.lt     #0x35a0a28
035A09A8  14 f3 00 f0  adrp     x20, #0x5403000
035A09AC  94 ca 41 f9  ldr      x20, [x20, #0x390]
035A09B0  18 7d 02 13  asr      w24, w8, #2
035A09B4  68 02 40 f9  ldr      x8, [x19]
035A09B8  e0 03 13 aa  mov      x0, x19
035A09BC  09 15 41 f9  ldr      x9, [x8, #0x228]
035A09C0  01 19 41 f9  ldr      x1, [x8, #0x230]
035A09C4  20 01 3f d6  blr      x9
035A09C8  aa 1e 40 b9  ldr      w10, [x21, #0x1c]
035A09CC  a8 0a 40 f9  ldr      x8, [x21, #0x10]
035A09D0  89 02 40 f9  ldr      x9, [x20]
035A09D4  4a 05 00 11  add      w10, w10, #1
035A09D8  aa 1e 00 b9  str      w10, [x21, #0x1c]
035A09DC  28 0c 00 b4  cbz      x8, #0x35a0b60
035A09E0  aa 1a 80 b9  ldrsw    x10, [x21, #0x18]
035A09E4  0b 19 40 b9  ldr      w11, [x8, #0x18]
035A09E8  e1 03 00 2a  mov      w1, w0
035A09EC  5f 01 0b 6b  cmp      w10, w11
035A09F0  c2 00 00 54  b.hs     #0x35a0a08
035A09F4  49 05 00 11  add      w9, w10, #1
035A09F8  08 09 0a 8b  add      x8, x8, x10, lsl #2
035A09FC  a9 1a 00 b9  str      w9, [x21, #0x18]
035A0A00  01 21 00 b9  str      w1, [x8, #0x20]
035A0A04  07 00 00 14  b        #0x35a0a20
035A0A08  28 11 40 f9  ldr      x8, [x9, #0x20]
035A0A0C  e0 03 15 aa  mov      x0, x21
035A0A10  08 61 40 f9  ldr      x8, [x8, #0xc0]
035A0A14  02 2d 40 f9  ldr      x2, [x8, #0x58]
035A0A18  48 04 40 f9  ldr      x8, [x2, #8]
035A0A1C  00 01 3f d6  blr      x8
035A0A20  18 07 00 71  subs     w24, w24, #1
035A0A24  81 fc ff 54  b.ne     #0x35a09b4
035A0A28  f4 03 1f 2a  mov      w20, wzr
035A0A2C  35 00 00 14  b        #0x35a0b00
035A0A30  68 02 40 f9  ldr      x8, [x19]
035A0A34  14 ef 00 f0  adrp     x20, #0x5383000
035A0A38  09 15 41 f9  ldr      x9, [x8, #0x228]
035A0A3C  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0A40  94 f2 40 f9  ldr      x20, [x20, #0x1e0]
035A0A44  1d 00 00 14  b        #0x35a0ab8
035A0A48  68 02 40 f9  ldr      x8, [x19]
035A0A4C  b5 ee 00 b0  adrp     x21, #0x5375000
035A0A50  09 15 41 f9  ldr      x9, [x8, #0x228]
035A0A54  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0A58  b5 e2 40 f9  ldr      x21, [x21, #0x1c0]
035A0A5C  e0 03 13 aa  mov      x0, x19
035A0A60  20 01 3f d6  blr      x9
035A0A64  68 02 40 f9  ldr      x8, [x19]
035A0A68  f4 03 00 2a  mov      w20, w0
035A0A6C  e0 03 13 aa  mov      x0, x19
035A0A70  09 15 41 f9  ldr      x9, [x8, #0x228]
035A0A74  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0A78  20 01 3f d6  blr      x9
035A0A7C  a8 02 40 f9  ldr      x8, [x21]
035A0A80  f5 03 00 2a  mov      w21, w0
035A0A84  e0 03 08 aa  mov      x0, x8
035A0A88  2c 6c 70 97  bl       #0x11bbb38
035A0A8C  a0 06 00 b4  cbz      x0, #0x35a0b60
035A0A90  e1 03 1f aa  mov      x1, xzr
035A0A94  f3 03 00 aa  mov      x19, x0
035A0A98  b3 ed 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A0A9C  74 56 02 29  stp      w20, w21, [x19, #0x10]
035A0AA0  2a 00 00 14  b        #0x35a0b48
035A0AA4  68 02 40 f9  ldr      x8, [x19]
035A0AA8  94 f0 00 f0  adrp     x20, #0x53b3000
035A0AAC  09 15 41 f9  ldr      x9, [x8, #0x228]
035A0AB0  01 19 41 f9  ldr      x1, [x8, #0x230]
035A0AB4  94 2a 43 f9  ldr      x20, [x20, #0x650]
035A0AB8  e0 03 13 aa  mov      x0, x19
035A0ABC  20 01 3f d6  blr      x9
035A0AC0  88 02 40 f9  ldr      x8, [x20]
035A0AC4  f4 03 00 2a  mov      w20, w0
035A0AC8  e0 03 08 aa  mov      x0, x8
035A0ACC  1b 6c 70 97  bl       #0x11bbb38
035A0AD0  80 04 00 b4  cbz      x0, #0x35a0b60
035A0AD4  f3 03 00 aa  mov      x19, x0
035A0AD8  e0 03 13 aa  mov      x0, x19
035A0ADC  e1 03 1f aa  mov      x1, xzr
035A0AE0  a1 ed 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A0AE4  74 12 00 b9  str      w20, [x19, #0x10]
035A0AE8  18 00 00 14  b        #0x35a0b48
035A0AEC  09 85 5d a9  ldp      x9, x1, [x8, #0x1d8]
035A0AF0  e0 03 13 aa  mov      x0, x19
035A0AF4  20 01 3f d6  blr      x9
035A0AF8  f4 03 00 2a  mov      w20, w0
035A0AFC  f7 03 1f 2a  mov      w23, wzr
035A0B00  88 f2 00 90  adrp     x8, #0x53f0000
035A0B04  08 75 42 f9  ldr      x8, [x8, #0x4e8]
035A0B08  00 01 40 f9  ldr      x0, [x8]
035A0B0C  0b 6c 70 97  bl       #0x11bbb38
035A0B10  80 02 00 b4  cbz      x0, #0x35a0b60
035A0B14  c8 1e 00 12  and      w8, w22, #0xff
035A0B18  1f 05 00 71  cmp      w8, #1
035A0B1C  e1 03 1f aa  mov      x1, xzr
035A0B20  f3 03 00 aa  mov      x19, x0
035A0B24  f6 17 9f 1a  cset     w22, eq
035A0B28  8f ed 12 94  bl       #0x3a5c164 ; System.Object$$.ctor
035A0B2C  e0 03 13 aa  mov      x0, x19
035A0B30  15 0c 02 f8  str      x21, [x0, #0x20]!
035A0B34  17 40 1f b8  stur     w23, [x0, #-0xc]
035A0B38  16 00 1f 38  sturb    w22, [x0, #-0x10]
035A0B3C  14 80 1f 38  sturb    w20, [x0, #-8]
035A0B40  e1 03 15 aa  mov      x1, x21
035A0B44  a9 6b 70 97  bl       #0x11bb9e8
035A0B48  e0 03 13 aa  mov      x0, x19
035A0B4C  f3 7b 43 a9  ldp      x19, x30, [sp, #0x30]
035A0B50  f5 53 42 a9  ldp      x21, x20, [sp, #0x20]
035A0B54  f7 5b 41 a9  ldp      x23, x22, [sp, #0x10]
035A0B58  f9 63 c4 a8  ldp      x25, x24, [sp], #0x40
035A0B5C  c0 03 5f d6  ret      
035A0B60  fa 6b 70 97  bl       #0x11bbb48
035A0B64  00 f0 00 90  adrp     x0, #0x53a0000
035A0B68  00 08 40 f9  ldr      x0, [x0, #0x10]
035A0B6C  b3 6b 70 97  bl       #0x11bba38
035A0B70  f2 6b 70 97  bl       #0x11bbb38
035A0B74  f3 03 00 aa  mov      x19, x0
035A0B78  45 d0 62 97  bl       #0xe54c8c
035A0B7C  40 f3 00 f0  adrp     x0, #0x540b000
035A0B80  00 d8 47 f9  ldr      x0, [x0, #0xfb0]
035A0B84  ad 6b 70 97  bl       #0x11bba38
035A0B88  f4 03 00 aa  mov      x20, x0
035A0B8C  20 ef 00 90  adrp     x0, #0x5384000
035A0B90  00 b8 47 f9  ldr      x0, [x0, #0xf70]
035A0B94  a9 6b 70 97  bl       #0x11bba38
035A0B98  e2 03 00 aa  mov      x2, x0
035A0B9C  e0 03 13 aa  mov      x0, x19
035A0BA0  e1 03 14 aa  mov      x1, x20
035A0BA4  e3 03 1f aa  mov      x3, xzr
035A0BA8  14 71 04 94  bl       #0x36bcff8 ; System.ArgumentException$$.ctor
035A0BAC  c0 f1 00 d0  adrp     x0, #0x53da000
035A0BB0  00 80 40 f9  ldr      x0, [x0, #0x100]
035A0BB4  a1 6b 70 97  bl       #0x11bba38
035A0BB8  e1 03 00 aa  mov      x1, x0
035A0BBC  e0 03 13 aa  mov      x0, x19
035A0BC0  d4 6b 70 97  bl       #0x11bbb10
