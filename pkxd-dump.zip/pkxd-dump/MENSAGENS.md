# Inventário inicial de mensagens

Este inventário foi extraído de `dump.cs`, produzido com os dois arquivos enviados. As linhas abaixo referem-se a esse arquivo específico; não são referências ao código-fonte original. Esta etapa identifica estruturas e pontos de análise. Não estabelece a implementação completa do protocolo.

## O que foi contado

Na imagem `Multiplayer.Scripts.Serialization.Protobuuf.dll` — esta é a grafia presente nos metadados — há 2.037 definições de tipos, incluindo auxiliares gerados pelo compilador. Dentro dessa imagem foram identificadas:

- **896 classes de mensagem** que implementam diretamente `Google.Protobuf.IMessage<T>`.
- **147 enums**, incluindo identificadores de eventos, erros e valores de domínio.
- **2.513 constantes `*FieldNumber`** nas classes de mensagem.

`protobuf_messages.tsv` relaciona todas essas classes, seu `TypeDefIndex`, linha do dump e constantes de número de campo. `protobuf_enums.tsv` relaciona os enums e seus valores declarados. Esses arquivos servem como índice pesquisável; não substituem os descritores `.proto`.

## Camada de transporte e envelope

Há uma camada própria denominada `ToxicBird`, distinta das mensagens Protobuf de gameplay.

| Evidência no dump | Estrutura observada | Implicação para a análise |
| --- | --- | --- |
| `ToxicBird.ToxicBirdClient`, linha 1088135 | `host`, `tcpPort`, `Nullable<int> udpPort`, campos concretos `TcpClient` e `UdpClient` | O cliente contém suporte a TCP e UDP. Ainda é necessário verificar quais caminhos esta versão utiliza em cada fluxo. |
| Métodos na mesma classe, linhas 1088255–1088270 | `ListenForData`, `ListenForUdpData`, `ReceiveMessage`, `SendMessage`, `SendMessageUnreliable`, `Authenticate` | São os alvos para reconstituir framing, leitura parcial de stream e distinção entre envio confiável e não confiável. |
| `ToxicBird.FeatherSerialization`, linha 1087983 | `Serialize(OutgoingMessage)`, `Deserialize(byte[])`, `CalculateOutputSize` | Define a serialização do envelope próprio; o dump contém assinaturas e endereços, mas não os corpos desses métodos. |
| `BigEndianBinaryReader`, linha 1087647; `BigEndianBinaryWriter`, linha 1087674 | Leitura/escrita de inteiros com conversão própria | Há helpers de big-endian. A largura e ordem de cada componente do pacote devem ser confirmadas nas rotinas nativas. |
| `ToxicBird.Event`, linha 1087621; `RoomEvent`, linha 1087634 | `EventName: string`, `Data: byte[]` | Eventos globais e eventos de sala têm nomes e payload binário como objetos em memória. Isso, sozinho, não determina a disposição desses valores na rede. |

Endereços nativos úteis:

| Método | RVA |
| --- | --- |
| `FeatherSerialization.Serialize` | `0x359FB04` |
| `FeatherSerialization.CalculateOutputSize` | `0x359FFA4` |
| `FeatherSerialization.Deserialize` | `0x35A0244` |
| `ToxicBirdClient.ReceiveMessage` | `0x35A30CC` |
| `ToxicBirdClient.SendMessage` | `0x35A2464` |
| `ToxicBirdClient.SendMessageUnreliable` | `0x35A2658` |
| `ToxicBirdClient.Authenticate` | `0x35A2DC4` |

Esses endereços pertencem à biblioteca ARM64 fornecida e precisam ser mapeados por seus segmentos ELF ao serem usados em ferramentas de análise.

### Famílias de envelope em memória

As classes `IncomingMessage.*` estão nas linhas 1087719–1087888 e `OutgoingMessage.*` nas linhas 1087895–1087979. Os nomes não revelam os bytes dos opcodes.

| Entrada, perspectiva do cliente | Dados declarados |
| --- | --- |
| `Ping`, `Pong`, `Disconnection` | Sem campos adicionais declarados |
| `Connected` | `playerId: int`, `playerKey: string` |
| `ConnectionFailed` | `failureReason: ConnectionFailureReason` |
| `Event`, `RoomEvent` | `eventName: string`, `data: byte[]` |
| `JoinedRoom` | `Success: bool`, `RoomId: int`, `FailureReason: byte`, `UsersInRoom: List<int>` |
| `LeftRoom` | `roomId: int` |
| `OtherUserJoinedRoom`, `OtherUserLeftRoom` | `roomId: int`, `userId: int` |
| `OtherUserConnected`, `OtherUserDisconnected` | `userId: int` |
| `Batch` | `messages: List<IncomingMessage>` |

| Saída, perspectiva do cliente | Dados declarados |
| --- | --- |
| `Ping`, `Pong`, `Connect` | Sem campos adicionais declarados |
| `Reconnect` | `playerKey: string` |
| `Event`, `RoomEvent` | `eventName: string`, `data: byte[]` |
| `JoinRoom`, `LeaveRoom` | `roomId: int` |

`PingFeature`, linha 1087543, inclui controle de RTT, intervalos, tentativas e timeout. As assinaturas não informam os valores efetivamente instalados em execução.

## Mensagens Protobuf e grupos de funcionalidades

Os nomes nesta tabela estão no namespace `Multiplayer.Scripts.Serialization.Protobuf`.

| Área | Tipos de referência e linha do dump |
| --- | --- |
| Login | `LoginRequest` (349691), `LoginResponse` (349815). Fluxo inicial detalhado em `PROTOCOLO_INICIAL.md`. |
| Lobby local | `LocalLobbyEventId` (349424), `LocalLobbyMessage` (349455) |
| Matchmaking | `LobbyType` (353245), `MatchmakingEventId` (353266), `GameServerType` (353279), `MatchmakingRequestMessage` (353324) |
| Estado do mundo | `GameVariablesCacheResponse` (341667), `VariableStateChangeRequest` (341777) |
| Avatar e animação | `AnimationData` (312679), `PlayerAnimationData` (312813), `AvatarCustomization` (319810) |
| Chat | `ChatMessageResponse` (319961), `SetOpenChatEnabledRequest` (384392), `OpenChatEnabledResponse` (385572) |
| Mochila | `BackpackEventId` (313790), `BackpackRequest` (313823), `BackpackResponse` (314301) |
| Casas | `HouseRequest` (344297), `HouseData` (344969), `HouseItem` (345261), `HouseRoom` (345385), `HouseResponse` (345497) |
| Amigos | `GetFriendRoomRequest` (336435), `FriendRoomResponse` (337401) |
| Pets | `PetRequestMessage` (366492), `PetResponseMessage` (366596), `PetPositionRequest` (367700), `GetPetsCacheResponse` (370578) |
| Veículos | `VehiclesEventId` (419430), `VehiclesRequest` (419622), `VehiclesResponse` (420748) |
| Horário | `TimeEventId` (416500), `TimeRequest` (416529), `GetCurrentTimeResponse` (416633) |
| Atividades e minijogos | `GetActivity` (309270), `ActivityRoom` (309856), `CrazyRunRequestMessage` (320414), `EggHuntRequestMessage` (328456), `ShooterModeRequest` (402524), `StaircaseRequestMessage` (411302) |

### Exemplos de constantes recuperadas

- `LocalLobbyEventId`: `Join = 0`, `Leave = 1`. `LocalLobbyMessage.EventIdFieldNumber = 1`.
- `MatchmakingEventId`: `JoinLobby = 0`, `LeaveLobby = 1`, `GetLobbyState = 2`. `MatchmakingRequestMessage.EventIdFieldNumber = 1`.
- `BackpackEventId`: `Purchase = 0`, `Remove = 1`, `Favorite = 2`. `BackpackRequest.EventIdFieldNumber = 1`.
- `TimeEventId.GetCurrentTime = 0`. `TimeRequest.EventIdFieldNumber = 1`.
- `VehiclesEventId`: `GetVehicles = 0`, `SpawnVehicle = 1`, `SwitchVehicle = 2`, `DespawnVehicle = 3`, `PerformAction = 4`, `InitializeVehicles = 5`, `PurchaseVehicles = 6`, `RentVehicle = 7`, `RemoveRentVehicle = 8`, `ChangeEquippedItems = 9`.

Esses são discriminadores dentro de grupos Protobuf. Não são, por si só, opcodes globais do envelope `FeatherSerialization`. Um campo C# `int` também não distingue automaticamente `int32`, `sint32` e `fixed32` no esquema Protobuf; descritores ou as rotinas `WriteTo`/`MergeFrom` são necessários para confirmar a codificação.

## Próximos passos antes do servidor

1. Reconstituir `FeatherSerialization` e os leitores/escritores do transporte; registrar tamanho, ordem de bytes, opcodes e tratamento de lotes com exemplos extraídos do código nativo.
2. Confirmar `Connect`/`Connected`, reconexão, ping/pong e a fronteira entre a autenticação do transporte e o login de gameplay.
3. Recuperar descritores Protobuf ou confirmar o wire type de cada campo usado na primeira etapa. Identificar como nomes de eventos e payloads são combinados pelas mecânicas.
4. Examinar os assets/configuração do APK para confirmar bootstrap, endereços, versões e dependências necessárias para chegar ao multiplayer.
5. Só então implementar uma primeira sequência reproduzível no Termux: transporte, sessão e login, seguida por estado inicial de uma sala. A mera existência das declarações não prova que respostas mínimas sejam suficientes para o cliente entrar no mundo.

Não foram feitas conexões com serviços do jogo, e nenhum servidor foi implementado nesta etapa.
