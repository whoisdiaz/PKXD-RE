# PK XD — mapa inicial de bootstrap, autenticação e conexão

Estudo estático do par `global-metadata.dat`/`libil2cpp.so` enviado nesta conversa. O metadata é IL2CPP v29 e a biblioteca é ARM64. A data de dezembro de 2023 é a identificação fornecida pelo usuário; ainda não foi confirmada por APK/manifesto.

As referências abaixo apontam para as linhas deste `dump.cs`. O dump contém declarações, constantes e endereços de código nativo; os corpos `{ }` não recuperam a implementação. Nenhum serviço do jogo foi consultado e nenhum servidor foi implementado neste estudo.

## O que já está identificado

| Camada | Evidência direta | Localização no dump |
|---|---|---|
| Contas/sessões Faster | `FasterClient` recebe `baseUrl`, `applicationKey`, `applicationSecret`; expõe criação de sessão de autenticação e de usuário. | `dump.cs:300353` |
| Host de contas | Constante `Config.AccountHost = "https://account-ipv4.faster.aftvrsys.com"`. É um endereço embutido, não prova de que esteja ativo. | `dump.cs:301609` |
| Alocação do servidor | `LobbyAPI` tem `LOBBY_HOST`, `LOBBY_FALLBACK_HOST`, `AllocatePlayer`, `ProcessLobbyResponse` e `AllocatePlayerWebRequest`. | `dump.cs:176691` |
| Resultado da alocação | `PlayerAllocationResponse` contém endereços, hosts e portas do servidor de jogo. | `dump.cs:298253` |
| Transporte do jogo | `ToxicBirdClient` contém instâncias de `TcpClient` e `UdpClient`, porta UDP opcional e threads de recepção separadas. | `dump.cs:1088135` |
| Serialização do transporte | `ToxicBird.FeatherSerialization` declara `Serialize`, `Deserialize` e `CalculateOutputSize`. | `dump.cs:1087983` |
| Login do jogo | `ToxicBirdServer.Login(string userToken, string referralSenderId, string appVersion)` e constante `LoginEventKey = "login"`. | `dump.cs:191176` e `dump.cs:190583` |
| Payloads de login | Classes geradas `Multiplayer.Scripts.Serialization.Protobuf.LoginRequest` e `LoginResponse`. | `dump.cs:349691` e `dump.cs:349815` |
| Continuação após conexão | `DefaultConnectionFlow` declara `OnConnection`, `OnAuthenticated`, `OnRoomJoined`; `InitialConnection` declara download de dependências/localização e início da cena. | `dump.cs:176986` e `dump.cs:177196` |

Há duas classes chamadas `LoginResponse`: a protobuf no namespace `Multiplayer.Scripts.Serialization.Protobuf`, e a representação interna em `PlayKids.XD.Multiplayer` (`dump.cs:298098`). É necessário manter essa distinção na análise.

## Dados de autenticação encontrados nas declarações

Todos os DTOs Faster desta tabela pertencem a `PlayKids.XD.Multiplayer.Server.Faster.Networking`. São nomes e tipos de campos recuperados; a estrutura JSON efetivamente transmitida ainda deve ser confirmada na serialização.

| DTO | Campos declarados | Linha |
|---|---|---:|
| `FasterAnonymousSignUpRequest` | `deviceInfo: FasterDeviceInfo`, `sentAt: long?`, `ntpSentAt: long?` | 300564 |
| `FasterAnonymousSignUpResponse` | `token: string` | 300715 |
| `FasterCreateAuthWithEmailSessionRequest` | `identityProvider: string`, `credentials: FasterEmailCredentials`, `deviceInfo`, `sentAt`, `ntpSentAt` | 300579 |
| `FasterCreateAuthSessionRequest` | `identityProvider: string`, `credentials: FasterTokenCredentials`, `deviceInfo`, `sentAt`, `ntpSentAt` | 300596 |
| `FasterTokenCredentials` | `type: string`, `token: string` | 300642 |
| `FasterEmailCredentials` | `type: string`, `email: string`, `password: string` | 300656 |
| `FasterCreateAuthSessionResponse` | `userId`, `sessionId`, `identity`, `identityType`, `authToken`: strings | 300760 |
| `FasterCreateUserSessionRequest` | `authToken: string`, `deviceInfo`, `sentAt`, `ntpSentAt` | 300613 |
| `FasterCreateUserSessionResponse` | `userId`, `sessionId`, `authSessionId`, `userToken`, `countryByIp`: strings | 300777 |

`FasterClient.GenerateRequestSignature(string method, string path, string query, byte[] bodyBytes)` está declarado com RVA `0x2E17E6C`. Sua presença mostra que há uma etapa de assinatura; não revela o algoritmo, os cabeçalhos ou a normalização dos dados. Não foram extraídos nem reproduzidos valores de credenciais de aplicação neste estudo.

## Alocação e conexão

`GenericAllocateRequest` (`dump.cs:176602`) declara:

- `userToken: string`;
- `gameServerProtocolVersion: string`;
- `isPrivate: bool`;
- `ApiPath` e `ToJsonBody()`.

Há variantes para destino por usuário/sala e para atividade (`AllocateActivityRequest`, `dump.cs:176545`). O nome `isPrivate` representa um campo do protocolo do cliente; não significa, por si só, que um servidor independente já esteja implementado.

`PlayerAllocationResponse` (`dump.cs:298253`) declara:

```text
successful: bool
failureReason: string
failureDescription: string
gameServerId: string
gameServerAddress: string
gameServerHosts: List<string>
gameServerPort: int
gameServerUdpPort: int
gameServerEngine: string
gameServerType: string
gameServerOwnerId: string
```

O método `CreateFromJSON(string)` reforça a existência de uma resposta JSON nessa camada. Os valores dos hosts de lobby, caminhos, método HTTP, cabeçalhos e regras de escolha entre endereço/lista de hosts ainda exigem leitura do código nativo ou uma captura correspondente.

## Login protobuf: números de campos recuperados

Os números abaixo são constantes `*FieldNumber` presentes no dump completo, acompanhadas dos respectivos campos/propriedades tipados. Não foram deduzidos pela ordem dos nomes.

`LoginRequest` — `dump.cs:349691`:

| Número | Propriedade | Tipo |
|---:|---|---|
| 1 | `UserToken` | `string` |
| 2 | `ReferralUserId` | `string` |
| 3 | `AppVersion` | `string` |

`LoginResponse` — `dump.cs:349815`:

| Número | Propriedade | Tipo |
|---:|---|---|
| 1 | `Successful` | `bool` |
| 2 | `ErrorMessage` | `string` |
| 3 | `IsNew` | `bool` |
| 4 | `IsOnboarding` | `bool` |
| 5 | `OnBoardingCompletedSteps` | `RepeatedField<string>` |

Isso permite reconstruir os campos centrais dessas duas mensagens. Ainda não determina o envelope que transporta os bytes protobuf, o nome exato de todas as respostas/eventos nem a sequência suficiente para entrar no mundo.

## Transporte: alvos exatos para a próxima leitura nativa

| Método | RVA observado | O que esclarecer |
|---|---:|---|
| `FeatherSerialization.Serialize` | `0x359FB04` | Identificadores de mensagens, ordem de campos, codificação de nomes/dados. |
| `FeatherSerialization.Deserialize` | `0x35A0244` | Tabela de mensagens recebidas e payloads de cada identificador. |
| `FeatherSerialization.CalculateOutputSize` | `0x359FFA4` | Cálculo do tamanho serializado. |
| `ToxicBirdClient.ReceiveMessage` | `0x35A30CC` | Framing TCP, prefixo de comprimento e limites de pacote. |
| `ToxicBirdClient.SendMessage` | `0x35A2464` | Framing de saída confiável. |
| `ToxicBirdClient.SendMessageUnreliable` | `0x35A2658` | Envelope e destino UDP. |
| `ToxicBirdClient.Authenticate` | `0x35A2DC4` | Handshake do transporte, separado do login de conta/jogo. |
| `ToxicBirdClient.TryConnectPlayer` | `0x35A4670` | Validação da resposta inicial e estabelecimento de identidade. |
| `ToxicBirdServer.Login` | `0x23B54F0` | Construção do protobuf e envio do evento de login. |
| `LobbyAPI..cctor` | `0x30AD25C` | Inicialização dos hosts de lobby. |
| `LobbyAPI.<AllocatePlayerWebRequest>d__4.MoveNext` | `0x30ADC04` | URL final, verbo HTTP e parâmetros da requisição de alocação. |
| `FasterClient.GenerateRequestSignature` | `0x2E17E6C` | Algoritmo e entradas da assinatura. |

Há classes `BigEndianBinaryReader`, `BigEndianBinaryWriter`, `IncomingMessage` e `OutgoingMessage`. As classes de saída incluem `Connect`, `Reconnect`, `Event`, `JoinRoom`, `LeaveRoom`, `RoomEvent`, `Ping` e `Pong`. Essas declarações não bastam para afirmar qual é o tamanho, opcode ou byte order de cada pacote; isso deve vir dos métodos de serialização.

## Hipótese de fluxo a verificar

Os tipos e assinaturas sugerem o caminho abaixo, mas ainda não foi confirmado como um único caminho de execução:

```text
bootstrap/configuração
  -> identidade/sessão Faster
  -> sessão de usuário (userToken)
  -> alocação no lobby
  -> conexão ToxicBird TCP e possível UDP
  -> handshake do transporte
  -> evento de login com LoginRequest protobuf
  -> LoginResponse
  -> entrada em sala e inicialização de dependências/cena
```

A distinção entre handshake do transporte, autenticação de conta e login do jogo é sustentada pela existência de métodos/DTOs distintos. A ordem exata e os requisitos de cada etapa permanecem pendentes de análise do código.

## Próximas evidências necessárias

1. Desmontar primeiro serialização, framing e handshake nos RVAs acima, registrando cada conclusão com instruções/referências concretas.
2. Recuperar os caminhos HTTP e a composição das requisições nas máquinas de estado assíncronas de Faster/lobby. A assinatura do método wrapper não contém necessariamente o corpo real da operação.
3. Inspecionar o APK correspondente para confirmar versão, configuração inicial, assets e dependências remotas exigidas para a cena.
4. Confrontar a especificação reconstruída com captura ou execução controlada do mesmo cliente. Nenhuma compatibilidade funcional foi testada até aqui.
5. Só então escolher e implementar o conjunto mínimo de serviços locais para Termux, com mensagens e respostas verificáveis. Uma resposta de login bem formada pode não ser suficiente para carregar o mundo.

Para navegar localmente no Termux, `grep -n` encontra esses nomes em `dump.cs`; os RVAs devem ser aplicados à biblioteca ARM64 correspondente. Os endereços virtuais no processo podem incluir a base de carregamento/ASLR e não devem ser confundidos automaticamente com endereços absolutos de memória.
