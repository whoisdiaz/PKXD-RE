# PK XD — dump IL2CPP e estudo inicial

Gerado a partir do par de arquivos fornecido pelo usuário: `global-metadata.dat`
versão 29 e `libil2cpp.so` ELF Android ARM64. A identificação como dezembro de
2023 foi informada pelo usuário; não foi confirmada por um APK/manifesto.

## Conteúdo

- `dump.cs`: declarações, tipos resolvidos, constantes, offsets de campos e RVAs.
- `DummyDll/`: 120 assemblies de referência e `Il2CppDummyDll.dll`, auxiliar.
- `script.json`, `stringliteral.json`, `il2cpp.h`: dados para análise nativa.
- Scripts Ghidra/IDA: auxiliares da distribuição oficial do Il2CppDumper.
- `PROTOCOLO_INICIAL.md`: mapa inicial de contas, sessões, lobby e login.
- `MENSAGENS.md`: mapa do transporte ToxicBird e grupos Protobuf.
- `protobuf_messages.tsv`: índice de 896 classes de mensagens, com números de campos.
- `protobuf_enums.tsv`: índice de 147 enums e suas constantes.
- `native/FeatherSerialization.arm64.asm`: desmontagem estática das três rotinas
  de serialização, tamanho e desserialização; chamadas diretas rotuladas usando
  `script.json`. Não é uma especificação validada do protocolo de rede.
- `string_literals_all.jsonl`: todos os 23.281 literais da tabela de metadados,
  em ordem, sem atribuir endereços nativos.
- `VALIDACAO.json`, `metadata_validation.json`: verificações estruturais.
- `Il2CppDumper.log`, `REPRODUCIBILIDADE.json`, `PROVENIENCIA.json`: ferramentas,
  hashes e resultado da segunda execução.
- `SHA256SUMS`: hashes dos arquivos do pacote, exceto o próprio manifesto.

## O que o dump representa

As declarações cobrem os 21.887 tipos e 146.636 métodos do metadata. Foram
validados 134.561 endereços diretos de métodos e 237.244 registros de métodos
no `script.json`, incluindo instanciações genéricas. Os métodos sem RVA direto
podem incluir abstratos e genéricos; não foram inventados endereços para eles.

Os corpos `{ }` do `dump.cs` e das Dummy DLLs não são as implementações
originais recuperadas. A lógica compilada permanece na biblioteca ARM64.
As DLLs são úteis para navegação em decompiladores .NET, não para executar o jogo.

O Il2CppDumper emitiu mapeamento nativo para 23.273 dos 23.281 literais. Os oito
restantes estão registrados em `VALIDACAO.json` sem endereço; o arquivo
`string_literals_all.jsonl` preserva os textos da tabela inteira.

O log contém a heurística `This file may be protected` após detectar
`JNI_OnLoad`. A busca automática encontrou CodeRegistration `0x50C9870` e
MetadataRegistration `0x52CB248` e concluiu as saídas. Esse aviso isolado não
prova proteção. Os resultados foram validados e os quatro arquivos principais
tiveram SHA-256 idêntico em uma segunda execução.

## Consulta no Termux

Após colocar o ZIP em uma pasta acessível ao Termux, execute nessa pasta:

```sh
pkg install unzip ripgrep
unzip pkxd-dump.zip
cd pkxd-dump
rg -n 'class LoginRequest|class LoginResponse' dump.cs
rg -n 'class ToxicBirdClient|class FeatherSerialization' dump.cs
rg -n 'Login|Backpack|House|Pet|TimeRequest' protobuf_messages.tsv
sha256sum -c SHA256SUMS
```

Os arquivos de texto podem ser consultados diretamente no Android. Não é
necessário instalar .NET para lê-los. O pacote não inclui os binários originais
enviados pelo usuário; conserve o par original para a análise de código nativo.
RVAs pertencem especificamente a essa biblioteca; endereços no processo ainda
dependem da base de carregamento.

## Reprodução da extração

Ferramenta: Il2CppDumper **v6.7.46**, pacote oficial `net6`, executado no Linux
x64 com runtime .NET **6.0.36**. A biblioteca alvo é ARM64; ela foi analisada como
dados, não executada. No `config.json` da ferramenta, apenas `RequireAnyKey` foi
alterado para `false`; as demais opções permaneceram no padrão da distribuição.
Não foi forçada versão, nem usada busca manual de registros.

Em uma máquina Linux com esse runtime e a distribuição oficial extraída:

```sh
mkdir -p resultado
dotnet /caminho/Il2CppDumper.dll /caminho/libil2cpp.so /caminho/global-metadata.dat "$PWD/resultado"
```

A pasta de resultado deve existir antes da chamada: essa versão ignora uma
pasta de saída inexistente e usa a pasta da própria ferramenta.

Fonte: https://github.com/Perfare/Il2CppDumper/releases/tag/v6.7.46
Desmontagem adicional: Capstone 5.0.7, modo ARM64 little-endian.

## Escopo desta entrega

Este é um dump validado e um estudo estático inicial. Não foi validado o
comportamento do cliente, a compatibilidade de um servidor, nem o protocolo
inteiro. A implementação do servidor será feita somente nas partes e na ordem
que o usuário solicitar. Nenhum servidor foi criado nesta etapa.
